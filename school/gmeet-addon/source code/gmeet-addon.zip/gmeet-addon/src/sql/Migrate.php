<?php

class Migrate
{
    protected $ci = '';
    
    public function  __construct()
    {
        $this->ci = & get_instance();
    }
    
    public function up()
    {
        $this->ci->db->query(
            "CREATE TABLE IF NOT EXISTS `gmeetliveclass` (
            `gmeetliveclassID` int(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `title` varchar(200) NOT NULL,
            `date` datetime NOT NULL,
            `duration` int(11) DEFAULT NULL,
            `classesID` int(11) NOT NULL,
            `sectionID` int(11) DEFAULT NULL,
            `url` varchar(200) NOT NULL,
            `description` text,
            `status` tinyint(4) NOT NULL,
            `schoolyearID` int(11) NOT NULL,
            `host` varchar(60) NOT NULL,
            `create_date` datetime NOT NULL,
            `modify_date` datetime NOT NULL,
            `create_userID` int(11) NOT NULL,
            `create_usertypeID` int(11) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
        );


        $gmeetLiveClassMenu                = $this->ci->db->query("SELECT * FROM menu WHERE menuName = 'gmeetliveclass'");
        $gmeetLiveClassPermission          = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass'");
        $gmeetLiveClassAddPermission       = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_add'");
        $gmeetLiveClassEditPermission      = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_edit'");
        $gmeetLiveClassDeletePermission    = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_delete'");
        $gmeetLiveClassViewPermission      = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_view'");

      
       
        if(!is_object($gmeetLiveClassMenu->row())) {
            $this->ci->db->query("INSERT INTO menu (menuName, link, icon, pullRight, status, parentID, priority) values('gmeetliveclass','gmeetliveclass','fa fa-file-video-o',NULL,'1','0','1000')");
        }


        if(!is_object($gmeetLiveClassPermission->row())) {
            $this->ci->db->query("INSERT INTO permissions (description, name, active) values('Gmeet Live Class','gmeetliveclass','yes')");
        }

        if(!is_object($gmeetLiveClassAddPermission->row())) {
            $this->ci->db->query("INSERT INTO permissions (description, name, active) values('Gmeet Live Class Add','gmeetliveclass_add','yes')");
        }

        if(!is_object($gmeetLiveClassEditPermission->row())) {
            $this->ci->db->query("INSERT INTO permissions (description, name, active) values('Gmeet Live Class Edit','gmeetliveclass_edit','yes')");
        }

        if(!is_object($gmeetLiveClassDeletePermission->row())) {
            $this->ci->db->query("INSERT INTO permissions (description, name, active) values('Gmeet Live Class Delete','gmeetliveclass_delete','yes')");
        }

        if(!is_object($gmeetLiveClassViewPermission->row())) {
            $this->ci->db->query("INSERT INTO permissions (description, name, active) values('Gmeet Live Class View','gmeetliveclass_view','yes')");
        }

       
        return true;

    }

    public function down()
    {
        $gmeetLiveClass                    = $this->ci->db->query("SELECT 1 FROM gmeetliveclass LIMIT 1");
        $gmeetLiveClassMenu                = $this->ci->db->query("SELECT * FROM menu WHERE menuName = 'gmeetliveclass'");
        $gmeetLiveClassPermission          = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass'");
        $gmeetLiveClassAddPermission       = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_add'");
        $gmeetLiveClassEditPermission      = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_edit'");
        $gmeetLiveClassDeletePermission    = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_delete'");
        $gmeetLiveClassViewPermission      = $this->ci->db->query("SELECT * FROM permissions WHERE name = 'gmeetliveclass_view'");
      

         if(is_object($gmeetLiveClass->row())) {
            $this->ci->db->query("DROP TABLE gmeetliveclass");
        }

        if(is_object($gmeetLiveClassMenu->row())) {
             $this->ci->db->query("DELETE FROM menu WHERE menuName='gmeetliveclass'");
        }


        if(is_object($gmeetLiveClassPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='gmeetliveclass'");
        }

        if(is_object($gmeetLiveClassAddPermission->row())) {
             $this->ci->db->query("DELETE FROM permissions WHERE name='gmeetliveclass_add'");
        }

        if(is_object($gmeetLiveClassEditPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='gmeetliveclass_edit'");
        }

        if(is_object($gmeetLiveClassDeletePermission->row())) {
             $this->ci->db->query("DELETE FROM permissions WHERE name='gmeetliveclass_delete'");
        }

        if(is_object($gmeetLiveClassViewPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='gmeetliveclass_view'");
        }

       
        return true;
    }
}
