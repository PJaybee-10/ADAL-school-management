<?php 
$lang['menu_gmeetliveclass'] = 'गुरमीत लाइव क्लास';
