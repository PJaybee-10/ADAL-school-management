<?php 
$lang['menu_gmeetliveclass'] = 'جميه لايف كلاس';
