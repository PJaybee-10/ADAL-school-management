<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet Live-Klasse';
