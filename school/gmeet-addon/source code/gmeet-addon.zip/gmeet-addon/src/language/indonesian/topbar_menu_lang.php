<?php 
$lang['menu_gmeetliveclass'] = 'Temui kelas langsung';
