<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet cours en direct';
