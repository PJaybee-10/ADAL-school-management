<?php 
$lang['menu_gmeetliveclass'] = 'Clasa live Gmeet';
