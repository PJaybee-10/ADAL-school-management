<?php
$lang['menu_gmeetliveclass']             = 'Gmeet live class';

