<?php 
$lang['menu_gmeetliveclass'] = 'গেমেট লাইভ ক্লাস';
