<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet clase en vivo';
