<?php 
$lang['menu_gmeetliveclass'] = 'Incontra lezioni dal vivo';
