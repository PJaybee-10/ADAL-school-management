<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet живой класс';
