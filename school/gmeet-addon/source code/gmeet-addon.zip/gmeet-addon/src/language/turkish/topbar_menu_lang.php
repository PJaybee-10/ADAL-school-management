<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet canlı sınıfı';
