<?php 
$lang['menu_gmeetliveclass'] = 'Gmeet现场直播';
