<?php

require_once('sql/Migrate.php');

class Init
{
    public $app_path    = '';
    protected $ci       = '';
    protected $sql      = '';

    public function  __construct()
    {
        $this->ci = & get_instance();
        $this->sql = new Migrate();
    }

    public function up($source, $destination)
    {
        try {
            $this->sql->up();
            $this->publish($source, $destination);
            $this->topbarLangPublish();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function down()
    {
        try {
            $this->topbarLangUnPublish();
            $this->unPublish();
            $this->sql->down();
            return true;
        } catch (Exception $e) {
            return false;
        }

    }

    public function unPublish()
    {

        if(version_compare(phpversion(), '7.0', '<')) {
            $jsonPath = realpath(__DIR__ . '/..').'/addons.json';
        } else {
            $jsonPath = dirname(__DIR__, 1).'/addons.json';
        }

        if(file_exists($jsonPath)) {
            $jsons = json_decode(file_get_contents($jsonPath));
            if(is_object($jsons)) {
                foreach ($jsons->files as $json) {
                    if(is_file(FCPATH.$json)) {
                        if(file_exists(FCPATH.$json)) {
                            unlink(FCPATH.$json);
                        }
                    } else {
                        $this->deleteDir(FCPATH.$json);
                    }
                }
            }
        }
    }

    public function deleteDir($dirPath) 
    {
        if (! is_dir($dirPath)) {
            throw new InvalidArgumentException("$dirPath must be a directory");
        }
        if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
            $dirPath .= '/';
        }
        $files = glob($dirPath . '*', GLOB_MARK);
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->deleteDir($file);
            } else {
                unlink($file);
            }
        }
        rmdir($dirPath);
    }


    private function publish( $source, $dest, $options = [ 'folderPermission' => 0777, 'filePermission' => 0777 ] )
    {
        $result = false;

        if ( is_file($source) ) {
            if ( $dest[ strlen($dest) - 1 ] == '/' ) {
                if ( !file_exists($dest) ) {
                    cmfcDirectory::makeAll($dest, $options['folderPermission'], true);
                }
                $__dest = $dest . "/" . basename($source);
            } else {
                $__dest = $dest;
            }
            $result = copy($source, $__dest);
            @chmod($__dest, $options['filePermission']);
        } elseif ( is_dir($source) ) {
            if ( $dest[ strlen($dest) - 1 ] == '/' ) {
                if ( $source[ strlen($source) - 1 ] == '/' ) {
                    //Copy only contents
                } else {
                    //Change parent itself and its contents
                    $dest = $dest . basename($source);
                    @mkdir($dest);
                    @chmod($dest, $options['filePermission']);
                }
            } else {
                if ( $source[ strlen($source) - 1 ] == '/' ) {
                    //Copy parent directory with new name and all its content
                    @mkdir($dest, $options['folderPermission']);
                    @chmod($dest, $options['filePermission']);
                } else {
                    //Copy parent directory with new name and all its content
                    @mkdir($dest, $options['folderPermission']);
                    @chmod($dest, $options['filePermission']);
                }
            }

            $dirHandle = opendir($source);
            while ( $file = readdir($dirHandle) ) {
                if ( $file != "." && $file != ".." ) {
                    if ( !is_dir($source . "/" . $file) ) {
                        $__dest = $dest . "/" . $file;
                    } else {
                        $__dest = $dest . "/" . $file;
                    }
                    $result = $this->publish($source . "/" . $file, $__dest, $options);
                }
            }
            closedir($dirHandle);
        } else {
            $result = false;
        }
        return $result;
    }

    private function topbarLangPublish()
    {
        $srcLang    = __DIR__ . '/language';

        if(is_dir($srcLang)) {
            $folders    = $this->replace(scandir($srcLang));
            $mvcLang    = APPPATH . 'language';
      
            foreach ($folders as $folder) {
                $srcTopLang = "{$srcLang}/{$folder}/topbar_menu_lang.php";
                $mvcTopLang = "{$mvcLang}/{$folder}/topbar_menu_lang.php";
                
                if(file_exists($mvcTopLang) && file_exists($srcTopLang)) {
                    $srcLangContent = $this->replace(file_get_contents($srcTopLang));
                    $mvcLangContent = file_get_contents($mvcTopLang);
                    file_put_contents($mvcTopLang, $mvcLangContent.$srcLangContent);
                }
            }
        }
    }

    private function topbarLangUnPublish()
    {
        $mvcLang    = APPPATH . 'language';
        $srcLang    = __DIR__ . '/language';
        if(is_dir($srcLang) && $mvcLang) {
            $folders    = $this->replace(scandir($mvcLang));

            foreach ($folders as $folder) {
                $srcTopLang = "{$srcLang}/{$folder}/topbar_menu_lang.php";
                $mvcTopLang = "{$mvcLang}/{$folder}/topbar_menu_lang.php";

                if(file_exists($mvcTopLang) && file_exists($srcTopLang)) {
                    $mvcLangContent = file_get_contents($mvcTopLang);
                    $srcLangContent = $this->replace(file_get_contents($srcTopLang));
                    $langExplodes   = explode("\n", trim($srcLangContent));

                    if(is_array($langExplodes)) {
                        foreach ($langExplodes as $langExplode) {
                            $mvcLangContent = str_replace($langExplode, '', $mvcLangContent);
                        }

                        file_put_contents($mvcTopLang, $mvcLangContent);
                    }
                }
            }
        }
    }

    private function replace($string)
    {
        if(is_array($string)) {
            if(count($string)) {
                unset($string[0], $string[1]);
            }
        } else {
            $string = str_replace('<?php', '', $string);
            $string = str_replace('?>', '', $string);
        }
        return $string;
    }
}
