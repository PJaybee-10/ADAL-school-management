<?php 
$lang['menu_tutorial'] = 'บทช่วยสอน';
$lang['menu_lesson'] = 'บทเรียน';
