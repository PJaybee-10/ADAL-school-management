<?php 
$lang['menu_tutorial'] = 'টিউটোরিয়াল';
$lang['menu_lesson'] = 'পাঠ';
