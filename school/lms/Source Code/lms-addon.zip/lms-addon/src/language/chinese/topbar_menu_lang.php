<?php 
$lang['menu_tutorial'] = '讲解';
$lang['menu_lesson'] = '课';
