<?php 
$lang['menu_tutorial'] = 'Didacticiel';
$lang['menu_lesson'] = 'Leçon';
