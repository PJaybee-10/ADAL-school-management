<?php 
$lang['menu_tutorial'] = 'ट्यूटोरियल';
$lang['menu_lesson'] = 'सबक';
