<?php 
$lang['menu_tutorial'] = 'Lernprogramm';
$lang['menu_lesson'] = 'Lektion';
