<?php 
$lang['menu_tutorial'] = 'Öğretici';
$lang['menu_lesson'] = 'Ders';
