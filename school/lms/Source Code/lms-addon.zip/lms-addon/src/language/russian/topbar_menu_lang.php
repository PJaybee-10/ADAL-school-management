<?php 
$lang['menu_tutorial'] = 'Руководство';
$lang['menu_lesson'] = 'Урок';
