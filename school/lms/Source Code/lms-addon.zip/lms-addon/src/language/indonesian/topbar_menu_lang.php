<?php 
$lang['menu_tutorial'] = 'Tutorial';
$lang['menu_lesson'] = 'Pelajaran';
