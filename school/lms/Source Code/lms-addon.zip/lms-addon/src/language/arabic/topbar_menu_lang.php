<?php 
$lang['menu_tutorial'] = 'الدورة التعليمية';
$lang['menu_lesson'] = 'درس';
