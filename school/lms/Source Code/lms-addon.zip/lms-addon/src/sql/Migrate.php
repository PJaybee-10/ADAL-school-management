<?php

class Migrate
{
    protected $ci = '';

    public function __construct()
    {
        $this->ci = &get_instance();
    }

    public function up()
    {
        $this->ci->db->query(
            "CREATE TABLE IF NOT EXISTS `lesson` (
              `lesson_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
              `title` varchar(765) DEFAULT NULL,
              `lesson_provider` tinyint(4) DEFAULT NULL,
              `video_url` text,
              `duration` varchar(60) DEFAULT NULL,
              `description` text,
              `tutorial_id` int(11) DEFAULT NULL,
              `file` varchar(255) DEFAULT NULL,
              `file_original_name` varchar(255) DEFAULT NULL,
              `video_file` varchar(255) DEFAULT NULL,
              `video_file_original_name` varchar(255) DEFAULT NULL,
              `thumbnail_picture` varchar(765) DEFAULT NULL,
              `create_userID` int(11) DEFAULT NULL,
              `create_usertypeID` int(11) DEFAULT NULL,
              `created_at` datetime DEFAULT NULL,
              `updated_at` datetime DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
        );

        $this->ci->db->query(
            "CREATE TABLE IF NOT EXISTS `tutorial` (
              `tutorial_id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
              `title` varchar(765) DEFAULT NULL,
              `classesID` int(11) DEFAULT NULL,
              `sectionID` int(11) DEFAULT NULL,
              `subjectID` int(11) DEFAULT NULL,
              `cover_photo` varchar(600) DEFAULT NULL,
              `is_public` tinyint(4) NOT NULL DEFAULT '0',
              `create_userID` int(11) DEFAULT NULL,
              `create_usertypeID` int(11) DEFAULT NULL,
              `updated_at` datetime DEFAULT NULL,
              `created_at` datetime DEFAULT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
        );

        $tutorialMenu             = $this->ci->db->query('SELECT * FROM menu WHERE menuName = "tutorial"');
        $tutorialPermission       = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial"');
        $tutorialAddPermission    = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_add"');
        $tutorialEditPermission   = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_edit"');
        $tutorialDeletePermission = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_delete"');
        $tutorialViewPermission   = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_view"');

        if (!is_object($tutorialMenu->row())) {
            $this->ci->db->query("insert into `menu` (`menuName`, `link`, `icon`, `pullRight`, `status`, `parentID`, `priority`) values('tutorial','tutorial','fa-leanpub',NULL,'1','0','1000')");
        }

        if (!is_object($tutorialPermission->row())) {
            $this->ci->db->query("insert into `permissions` (`description`, `name`, `active`) values('Tutorial','tutorial','yes')");
        }

        if (!is_object($tutorialAddPermission->row())) {
            $this->ci->db->query("insert into `permissions` (`description`, `name`, `active`) values('Tutorial Add','tutorial_add','yes')");
        }

        if (!is_object($tutorialEditPermission->row())) {
            $this->ci->db->query("insert into `permissions` (`description`, `name`, `active`) values('Tutorial Edit','tutorial_edit','yes')");
        }

        if (!is_object($tutorialDeletePermission->row())) {
            $this->ci->db->query("insert into `permissions` (`description`, `name`, `active`) values('Tutorial Delete','tutorial_delete','yes')");
        }

        if (!is_object($tutorialViewPermission->row())) {
            $this->ci->db->query("insert into `permissions` (`description`, `name`, `active`) values('Tutorial View','tutorial_view','yes')");
        }

        return true;

    }

    public function down()
    {
        $this->ci->db->query("DROP TABLE IF EXISTS tutorial");
        $this->ci->db->query("DROP TABLE IF EXISTS lesson");

        $tutorialMenu             = $this->ci->db->query('SELECT * FROM menu WHERE menuName = "tutorial"');
        $tutorialPermission       = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial"');
        $tutorialAddPermission    = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_add"');
        $tutorialEditPermission   = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_edit"');
        $tutorialDeletePermission = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_delete"');
        $tutorialViewPermission   = $this->ci->db->query('SELECT * FROM permissions WHERE name = "tutorial_view"');

        if (is_object($tutorialMenu->row())) {
            $this->ci->db->query("DELETE FROM menu WHERE menuName='tutorial'");
        }

        if (is_object($tutorialPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='tutorial'");
        }

        if (is_object($tutorialAddPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='tutorial_add'");
        }

        if (is_object($tutorialEditPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='tutorial_edit'");
        }

        if (is_object($tutorialDeletePermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='tutorial_delete'");
        }

        if (is_object($tutorialViewPermission->row())) {
            $this->ci->db->query("DELETE FROM permissions WHERE name='tutorial_view'");
        }

        return true;
    }
}
